# AI Dev Playbook
Use AI as a tool, not a crutch.