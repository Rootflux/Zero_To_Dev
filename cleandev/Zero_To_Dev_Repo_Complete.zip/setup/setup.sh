#!/bin/bash
echo 'Dev setup script executed.'